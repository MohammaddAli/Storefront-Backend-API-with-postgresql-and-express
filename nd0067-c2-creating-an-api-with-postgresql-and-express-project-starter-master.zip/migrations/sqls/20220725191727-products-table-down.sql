/* Replace with your SQL commands */
DROP TABLE products;